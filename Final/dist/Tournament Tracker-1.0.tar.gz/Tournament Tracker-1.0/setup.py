
from setuptools import setup

setup(name='Tournament Tracker', version='1.0', author='Joseph Lewis', author_email='joseph.p.lewis@wsu.edu', py_modules=['tournament'])
